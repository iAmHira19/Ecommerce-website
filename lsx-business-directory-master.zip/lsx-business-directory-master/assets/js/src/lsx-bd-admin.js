/**
 * LSX Starter Plugin scripts (admin).
 *
 * @package lsx-business-directory
 */

var LSX_BD_ADMIN = Object.create( null );

;( function( $, window, document, undefined ) {

	'use strict';

    LSX_BD_ADMIN.document = $( document );

} )( jQuery, window, document );
